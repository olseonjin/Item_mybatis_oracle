package com.lgy.item_mybatis_oracle.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.item_mybatis_oracle.dao.ItemDAO;
import com.lgy.item_mybatis_oracle.dto.ItemDTO;

@Service("ItemService")
public class ItemServicelmpl implements ItemService{

	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public ArrayList<ItemDTO> list() {
		ItemDAO dao=sqlsession.getMapper(ItemDAO.class);
		ArrayList<ItemDTO> list = dao.list();
		return list;
	
	}
	
	@Override
	public void write(HashMap<String, String> param) {
		ItemDAO dao=sqlsession.getMapper(ItemDAO.class);
		dao.write(param);
		
	}
	@Override
	public ItemDTO contentView(HashMap<String, String> param) {
		ItemDAO dao=sqlsession.getMapper(ItemDAO.class);
		ItemDTO dto = dao.contentView(param);
		
		return dto;
	}


}
