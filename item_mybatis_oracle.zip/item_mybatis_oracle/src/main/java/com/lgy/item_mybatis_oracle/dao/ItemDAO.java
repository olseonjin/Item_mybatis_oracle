package com.lgy.item_mybatis_oracle.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.lgy.item_mybatis_oracle.dto.ItemDTO;

//public class ItemDAO {
public interface ItemDAO {
	public ArrayList<ItemDTO> list();
	public void write(HashMap<String, String> param);
	public ItemDTO contentView(HashMap<String, String> param);


}
